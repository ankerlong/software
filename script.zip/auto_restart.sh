#!/bin/bash                 #
#Name:auto_restart jetty    #
#Author:Anker               #  
#Date:2018-06-28            #
#Email:muxlong@outlook.com  #
#############################
#------Variable-------------
#code='curl -s -i -X  GET --head -m 3 "http://10.138.22.13:1026/com.haier.openplatform.hac.service.HacUserServiceCli?wsdl" |awk 'NR==1{print $2}''
#PID=$`lsof -i:1026 |awk 'NR==2{print $2}'`

logfile=/home/textport/deploy/hac1169-service-impl-2.1.0-SNAPSHOT/logs/stdout.log
OK=200
code=`curl -s -i -X  GET --head -m 3 "http://10.138.8.204:33333" |awk 'NR==1{print $2}'`
#PID=`lsof -i:33333 |awk 'NR==2{print $2}'`
PID=`ps aux |grep tomcat |grep hopdeploy |grep -v grep |awk '{print $2}'`
bin=/home/hopdeploy/tomcat/bin/startup.sh

function restart()
{
    if [ ! -n "$PID" ];then
       echo "$PID"
       kill -9 $PID
       sh $bin
       sleep 5
    else
       sh $bin
    fi
}

function monitor()
{
if [ "$code"x == "$OK"x ];then

     echo "应用启动成功！当前PID为:$PID"

       exit
fi
}

 if [ "$code"x == "$OK"x ];then
       echo "应用正常,PID:$PID"
       exit
    else
       restart
    fi
















