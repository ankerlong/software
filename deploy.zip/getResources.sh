#!/bin/bash
df -h
free -m
cat /proc/cpuinfo

