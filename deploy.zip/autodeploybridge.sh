#!/bin/bash
FUNFTP(){
ftp -in 10.138.8.204 << SCRIPTEND
  user hopdeploy tobeno.1
  binary
  cd FTP
  cd $1
  cd $3 
  get $2
  bye
SCRIPTEND
}

# deploy project
FUNDEP(){
cd ~
cd project
backtime=`date +%m%d%H%M%S`
if [ ! -d "back" ];then
        mkdir back
fi
if [ ! -f "$2" ];then
      FUNFTP $1 $2 $3
   else
      mv $2 back/$2.bak.$backtime
      FUNFTP $1 $2 $3
fi
#计算文件夹数量,删除多余备份
backnum=`ls -l ./back|grep "^-"|wc -l`
if [[ ${backnum} -gt 7 ]];then
        file=`ls -t ./back|tac |head -n 1`
        rm -rf back/$file
fi
}

# rollback project 
FUNROL(){
cd ~
cd project
if [ ! -f "$2,bak" ];then
   if [ ! -f "$2" ];then
      echo "$2 no found ,pleas try agen!"
   else
      echo "only $2 ,don't found backup!"
   fi
else
   rm -rf $2
   mv $2.bak $2
fi
}

##################  deploying ###########################
if [ $4 == 1 ];then
   FUNDEP $1 $2 $3
   cd ~/jetty/bin
   bash jetty.sh restart
else
   FUNROL $1 $2 $3 
   cd ~/jetty/bin
   bash jetty.sh restart
fi
sleep 1m
date=$(date +%Y_%m_%d)
isStart=`grep 'ERROR' ~/jetty/logs/$date.stderrout.log |wc -l`
isFailed=`grep 'initialization failed' ~/jetty/logs/$date.stderrout.log |wc -l`
if [ $isFailed -gt 0 ];then
   echo "deploying error!"
else
   echo "deploying sucessful!"
fi
