#!/bin/bash
#$1 ---> appliction Abbreviation
#$2 ---> deploying package
#$3 ---> date path
#$4 ---> 1 ---> deploy 0 ---> Rollback
FUNFTP(){
  ftp -in 10.135.13.113 << SCRIPTEND
  user haieradmin Haier,123
  binary
     cd FTP
     cd $Abbreviation
     cd $path
     get $packagename
  bye
SCRIPTEND
}
FUNDEP(){
   rm -rf *.bak *.tar
   dirname=`basename $packagename -package.tar`
   PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
   sid=`ps -ef|grep 'bash $dirname/bin/start.sh'|grep -v grep |awk  '{print $2}'`
   if [  -n "$PID" ]; then 
       echo "PID num is $PID" 
            kill -9 $PID
       kill -9 $sid
   else
      echo "no find PID!"
   fi 
   path=$dir/$dirname
   if [ ! -d "$path" ];then
        echo "no find dir"
   else
        mv $dirname $dirname.bak
   fi
   FUNFTP $Abbreviation $packagename $path
   tar xvf $packagename
   chmod +x */bin/*
   nohup bash $dirname/bin/start.sh >start.log &
   sleep 1m
   PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
   if [  -n "$PID" ]; then 
      echo "deploying successful!"       
  else
      echo "deploying error!"
  fi 
}
FUNROL(){
  dirname=`basename $packagename -package.tar`
  PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
  sid=`ps -ef|grep 'bash $dirname/bin/start.sh'|grep -v grep |awk  '{print $2}'`
  if [  -n "$PID" ]; then
    echo "PID num is $PID" 
    kill -9 $PID
    kill -9 $sid
  else
    echo "no find PID"
  fi
  rm -rf $dirname
  cp -r $dirname.bak $dirname
  chmod +x */bin/*
  nohup bash $dirname/bin/start.sh >start.log &
  sleep 1m
  PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
  if [  -n "$PID" ]; then
      echo "deploying successful!" 
  else
      echo "deploying error!"
  fi
}
##################  deploying ###########################
  Abbreviation=$1
  packages=$2
  path=$3
  cd ~
  dir=dubbo
  if [ ! -d "$dir" ];then
       mkdir $dir
       cd $dir
       echo `pwd`
  else
       cd $dir
  fi
##判断是不是存在多个文件。
if [[ $packages =~ "," ]]; then
    var=${packages//,/ }    #这里是将var中的,替换为空格  
    for packagename in $packages   
      do  
        echo $packagename  
        if [ $4 == 1 ];then
          FUNDEP $Abbreviation $packagename $path
        else 
          FUNROL $Abbreviation $packagename $path
        fi
    done  
else
  packagename=$2
  if [ $4 == 1 ];then
      FUNDEP $Abbreviation $packagename $path
  else 
      FUNROL $Abbreviation $packagename $path
  fi
fi

