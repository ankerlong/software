#!/bin/bash
FUNFTP(){
  ftp -in 10.135.13.113 << SCRIPTEND
    user haieradmin Haier,123
    binary
    cd FTP
    cd $1
    cd $3
    get $2
    bye
SCRIPTEND
}
FUNDEP(){
  cd ~
  dir=public
  if [ ! -n $dir ]; then
    FUNFTP $1 $2 $3
    tar xvf $2
    cd ~/rsync
    bash rsync.sh
  else
    mv public public.bak
    FUNFTP $1 $2 $3
    tar xvf $2
    cd ~/rsync
    bash rsync.sh
  fi
}
FUNROL(){
   cd ~
  dir=public.bak
  if [ ! -n $dir ]; then
    echo "deploying error!"
    echo "no find dir"
  else
    mv public.bak public
    cd ~/rsync
    bash rsync.sh
  fi
}

fileEr=`grep "rsync: write failed on" *`
rsyncEr=`grep "ERROR" *`
##################  deploying ###########################

if [ $4 == 1 ];then 
   FUNDEP $1 $2 $3
   if [[ -n $fileEr ]]; then
     echo "磁盘空间不够，所以无法操作。"
   elif [[ -n $rsyncEr ]]; then
       echo "deploying error!"
   else
       echo "deploying sucessful!"
   fi
   
else
  if [[ -n $fileEr ]]; then
     echo "磁盘空间不够，所以无法操作。"
   elif [[ -n $rsyncEr ]]; then
       echo "deploying error!"
   else
       echo "deploying sucessful!"
   fi
fi
    
