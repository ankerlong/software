#!/bin/bash                 #
#Name:auto_restart jetty    #
#Author:Anker               #  
#Date:2018-06-28            #
#Email:muxlong@outlook.com  #
#############################
#------Variable-------------
OK=200
#code=`curl -s -i -X  GET --head -m 3 "http://10.138.8.203:1024/com.haier.openplatform.hac.service.HacUserServiceCli?wsdl" |awk 'NR==1{print $2}'`
code=`curl -s -i -X  GET --head -m 3 "http://10.138.8.204:33333" |awk 'NR==1{print $2}'`
logfile=/home/textport/deploy/hac1169-service-impl-2.1.0-SNAPSHOT/logs/stdout.log
Date=`date +%Y-%m-%d+%H:%M:%S`
status1=`grep 'Catalina.start Server startup in' /home/hopdeploy/tomcat/logs/catalina.out`
PID=`ps aux |grep /home/hopdeploy/tomcat |grep hopdeploy |grep -v grep|awk '{print $2}'`

#bin=/home/textport/deploy/hac1169-service-impl-2.1.0-SNAPSHOT/bin/start.sh
bin=/home/hopdeploy/tomcat/bin/startup.sh


function restart()
{

  if [ ! -n "$PID" ];then
   ps aux |grep tomcat |grep hopdeploy |grep -v grep|awk '{print $2}' |xargs -i kill -9 {} 
      sh /home/hopdeploy/tomcat/bin/startup.sh  
  else
      sh /home/hopdeploy/tomcat/bin/startup.sh
  fi
}

function statustip()
{
if [ ! -n "$status1" ]; then
   echo "启动成功，time:$Date" >> restartHAC.log 
   echo '10.138.8.204启动成功' | mail -s '重启TIPS' -r root@root  389554843@qq.com
   exit
fi
}


 if [ "$code" == "$OK" ];then
       echo "应用正常,PID:$PID,Time:$Date" >> restartHAC.log
       #exit
    else
    ps aux |grep tomcat |grep hopdeploy |grep -v grep|awk '{print $2}' |xargs -i kill -9 {}
    nohup sh /home/hopdeploy/tomcat/bin/startup.sh &
    statustip
fi
