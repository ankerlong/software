##########################################################################
# [1]:weblogic home path                                                 #                                       
# [2]:weblogic console url(t3://xxx)                                     #
# [3]:weblogic username                                                  #                                       
# [4]:weblogic password                                                  #
# [5]:ftp ip                                                             #
# [6]:ftp username                                                       #
# [7]:ftp password                                                       #
# [8]:home path                                                          #
# [9]:weblogic war package name                                          #
# [10]:if specified with '1' undeploy all wars before deploy new war     #
##########################################################################


WL_HOME=$1
currTime=$(date +%y-%m-%d-%H-%M-%S)
echo "************** $currTime ************" >> hopdeploy.log
echo $9 >> hopdeploy.log
echo "************** $currTime ************" >> hopdeploy.log
echo "" >> hopdeploy.log

echo "********************** begin setWLSEnv.sh *********************"
.  $WL_HOME/server/bin/setWLSEnv.sh
echo "********************** end setWLSEnv.sh *********************"
echo "*************begin weblogic.WLST--autodeploy*****************"
java weblogic.WLST ~/autodeploy.py $2 $3 $4 $5 $6 $7 $8 $9 ${10}
echo "*************end weblogic.WLST--autodeploy*****************"
if [ -f "$9" ]; then
	rm $9
fi
