#!/bin/bash
#$1 ---> appliction Abbreviation
#$2 ---> deploying package
#$3 ---> date path
#$4 ---> 1 ---> deploy | 0 ---> Rollback
FUNFTP(){
  ftp -in 10.138.8.204 << SCRIPTEND
  user hopdeploy tobeno.1
  binary
     cd FTP
     cd $1
     cd $3
     get $2
  bye
SCRIPTEND
}
FUNDEP(){
#   rm -rf *.bak *.tar *.log
   dirname=`basename $2 -package.tar`
   rm -rf $dirname.bak 
   PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
   sid=`ps -ef|grep 'bash $dirname/bin/start.sh'|grep -v grep |awk  '{print $2}'`
   if [  -n "$PID" ]; then 
       echo "PID num is $PID" 
            kill -9 $PID
       kill -9 $sid
   else
      echo "no find PID!"
   fi
   time=`date +%m%d%H%M%S`
   if [ ! -d "dubbo/back" ];then
        mkdir ~/dubbo/back
   fi 
#   cd dubbo
   path=$dirname
   if [ ! -d "$path" ];then
        echo "no find dir"
   else
        mv ~/dubbo/$dirname ~/dubbo/back/$dirname.bak.$time
   fi
   #计算文件夹数量,删除多余备份
   backnum=`ls -l ./back|grep "^-"|wc -l`
   if [[ ${backnum} -gt 7 ]];then
        backfile=`ls -t ./back|tac |head -n 1`
        rm -rf back/$backfile
   fi
   FUNFTP $1 $2 $3
   tar xvf $2
   chmod +x */bin/*
   nohup bash $dirname/bin/start.sh >start.log &
   sleep 1m
   PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
   if [  -n "$PID" ]; then 
      echo "deploying successful!"       
  else
      echo "deploying error!"
  fi 
}
FUNROL(){
  dirname=`basename $2 -package.tar`
  PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
  sid=`ps -ef|grep 'bash $dirname/bin/start.sh'|grep -v grep |awk  '{print $2}'`
  if [  -n "$PID" ]; then
    echo "PID num is $PID" 
    kill -9 $PID
    kill -9 $sid
  else
    echo "no find PID"
  fi
  rm -rf $dirname
  cp -r $dirname.bak $dirname
  chmod +x */bin/*
  nohup bash $dirname/bin/start.sh >start.log &
  sleep 1m
  PID=`ps -ef|grep ~/dubbo/$dirname |grep -v grep |awk  '{print $2}'`
  if [  -n "$PID" ]; then
      echo "deploying successful!" 
  else
      echo "deploying error!"
  fi
}
##################  deploying ###########################
echo $(date +%Y%m%d)
  cd ~
  dir=dubbo
  if [ ! -d "$dir" ];then
       mkdir $dir
       cd $dir
       echo `pwd`
  else
       cd $dir
  fi

if [ $4 == 1 ];then
  FUNDEP $1 $2 $3
else 
   FUNROL $1 $2 $3
fi
echo $(date +%Y%m%d)
