#!/bin/bash
#$1 ---> appliction Abbreviation
#$2 ---> deploying package
#$3 ---> date path
#$4 ---> 1 ---> deploy 0 ---> Rollback
#$5 ---> path
FUNFTP(){
  ftp -in 10.135.13.113 << SCRIPTEND
  user haieradmin Haier,123
  binary
     cd FTP
     cd $1
     cd $3
     get $2
  bye
SCRIPTEND
}
FUNDEP(){
  PID=`ps -ef|grep $5 |grep tomcat |grep -v grep |awk  '{print $2}'`
  if [  -n "$PID" ]; then 
       echo "PID num is $PID" 
            kill -9 $PID
   else
      echo "no find PID!"
   fi 
  cd $5
  cd webapps
  if [[ -f $2.bak ]]; then
    rm -rf $2.bak
  fi
  mv $2 $2.bak
  FUNFTP $1 $2 $3 
  if [[ -f $2 ]]; then
    cd $5
    cd bin
    bash startup.sh
  else 
     exit 0
  fi 
  PID=`ps -ef|grep $5 |grep tomcat |grep -v grep |awk  '{print $2}'`
  if [  -n "$PID" ]; then 
       echo "deploying successful!" 
            
   else
      echo "deploying error!"
   fi 
}
FUNROL(){
  PID=`ps -ef|grep $5 |grep tomcat |grep -v grep |awk  '{print $2}'`
  
  cd $5
  cd webapps
  if [[ -f $2.bak ]]; then
    if [  -n "$PID" ]; then 
       echo "PID num is $PID" 
            kill -9 $PID
   else
      echo "no find PID!"
   fi 
    mv $2.bak $2 
  else
    exit 0
  fi
  if [[ -f $2 ]]; then
    cd $5
    cd bin
    bash startup.sh
  else 
     exit 0
  fi 
  PID=`ps -ef|grep $5 |grep tomcat |grep -v grep |awk  '{print $2}'`
  if [  -n "$PID" ]; then 
       echo "deploying successful!" 
            
   else
      echo "deploying error!"
   fi 
}
##################  deploying ###########################
  cd ~
  dir=dubbo
  if [ ! -d "$dir" ];then
       mkdir $dir
       cd $dir
       echo `pwd`
  else
       cd $dir
  fi

if [ $4 == 1 ];then
  FUNDEP $1 $2 $3
else 
   FUNROL $1 $2 $3
fi
