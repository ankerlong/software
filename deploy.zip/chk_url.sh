fileurl='./url.txt'
for chkurl in $(cat ${fileurl})    # ${}忽略空格
do
    # -o 输出内容到/dev/null; -s 静默方式 ；-w 定义显示输出格式；"%{http_code}" 在最后被检索的 HTTP(S) 页中被找到的数字的代码
    HTTP_CODE=`curl -o /dev/null -s -w "%{http_code}" "${chkurl}"` 
        if [ ${HTTP_CODE} -ne 200 ];then
	      echo -e "the url has error\npls chk it\n"$chkurl"    ${HTTP_CODE}" 
	      cat error.log
#|mail -s "url_error" jiangzd102@outlook.com,yuanhang@0504
	 else
	      echo "No Problem :-) :"${HTTP_CODE}
	 fi
done
