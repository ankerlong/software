export JAVA_HOME=/opt/jdk
export PATH=$JAVA_HOME/bin:$PATH
export PATH=$M2_HOME/bin:$PATH

java -version
