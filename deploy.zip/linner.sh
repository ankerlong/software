#!/bin/bash
path=$1
cd $path
linner watch >$2_linner.log 
while [[ $success -ne 1 ]]
do
success=`grep ': Done in' $2_linner.log |wc -l`
error=`grep 'error' $2_linner.log |wc -l`
if [[ $error -gt 0 ]] ;then
   break
fi
sleep 2
done
cat $2_linner.log 
PID=`ps -ef|grep 'linner watch >$2_linner.log' |grep -v grep |awk  '{print $2}'`
PSD=`ps -ef|grep linner |grep -v grep |awk  '{print $2}'`
kill -9 $PID $PSD
zip -r  $2_public.zip ./public


