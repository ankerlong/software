#!/bin/bash
FUNFTP(){
  ftp -in 10.135.16.65 << SCRIPTEND
  user webftp webftp
  binary
  cd software
  get jetty.xml
  get jetty-distribution-8.1.14.v20131031.tar.gz
  bye
SCRIPTEND
}
if [ $# -ne 3 ]; then
        echo "parameter should 3"
        exit 1
fi
# $1
if [[ "$1" =~ "^[a-zA-Z]+$" ]]; then
        echo "1 = letter"
else
        echo "The first argument must be a letter"
        exit 2
fi          
# $2  no panduan
# $3    
        expr $3 "+" 10 &> /dev/null
        if [ $? -eq 0 ]; then
                echo "3 = number"
        else
                echo "The third argument must be a number"
        exit 3
        fi
sysname=$1
appname=$2
port=$3
echo "download jetty package!"
FUNFTP
echo "Extract jetty package!"
tar -xzvf jetty-distribution-8.1.14.v20131031.tar.gz
ln -s jetty-distribution-8.1.14.v20131031 jetty
echo "delete unnecessary files!"
rm -rf jetty/contexts/*
echo "delete contexts succeed!"
sed -i "s/sysname/$sysname/g" jetty.xml
sed -i "s/appname/$appname/g" jetty.xml
mv jetty.xml jetty/contexts/$sysname.xml
mkdir -p project/assets
rm jetty-distribution-8.1.14.v20131031.tar.gz
echo "delete packge succeed!"
cd $HOME/jetty/etc
sed -i "s/8080/$port/" jetty.xml
cd ../bin
sed -i -e '83a JAVA_OPTIONS=" -Xmx2048m -Xmx2048m -XX:PermSize=512M"' jetty.sh
echo "port modify succeed"

